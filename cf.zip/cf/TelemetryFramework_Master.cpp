// Telemetry Framework - Master Build (Final Fixed)
#define NOMINMAX
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <TlHelp32.h>
#include <d3d11.h>
#include <dxgi1_6.h>
#include <immintrin.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <limits>
#include <locale>
#include <memory>
#include <mutex>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <type_traits>
#include <utility>
#include <vector>
#include "imgui.h"
#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "user32.lib")
static_assert(sizeof(void*) == 8, "Requer x64.");
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

template<size_t N>
struct ObfuscatedString {
    char data[N];
    constexpr ObfuscatedString(const char (&text)[N]) : data{} {
        for (size_t i = 0; i < N; ++i) data[i] = text[i] ^ 0x5A;
    }
    std::string decrypt() const {
        std::string out(N - 1, '\0');
        const volatile char* encrypted = data;
        for (size_t i = 0; i + 1 < N; ++i) out[i] = encrypted[i] ^ 0x5A;
        return out;
    }
};

template<std::size_t N>
constexpr ObfuscatedString<N> no7MakeUiString(const char (&literal)[N]) noexcept {
    return ObfuscatedString<N>(literal);
}

#define NO7_UI_STR(literal)                                                   \
    ([]() -> const std::string& {                                             \
        static constexpr auto no7Encrypted = no7MakeUiString(literal);        \
        static thread_local const std::string no7Decrypted =                  \
            no7Encrypted.decrypt();                                          \
        return no7Decrypted;                                                  \
    }())

namespace NO7::UI {
struct PerformanceStats { float FPS = 0, FrameTimeMs = 0, SmoothedFrameTimeMs = 0; uint64_t FrameCount = 0; };
class Optimizer final {
    PerformanceStats stats_{};
public:
    void BeginFrame() noexcept {
        const float dt = ImGui::GetIO().DeltaTime;
        if (!std::isfinite(dt) || dt <= 0) return;
        stats_.FrameTimeMs = dt * 1000;
        if (!stats_.FrameCount) stats_.SmoothedFrameTimeMs = stats_.FrameTimeMs;
        else stats_.SmoothedFrameTimeMs += (stats_.FrameTimeMs - stats_.SmoothedFrameTimeMs) * -std::expm1(-std::min(dt, 1.0f) * 8);
        stats_.FPS = stats_.SmoothedFrameTimeMs > 0 ? 1000 / stats_.SmoothedFrameTimeMs : 0;
        ++stats_.FrameCount;
    }
    const PerformanceStats& GetStats() const noexcept { return stats_; }
};
}

namespace NO7::UI::Extended {
struct Rect {
    ImVec2 Min, Max;
    bool IsValid() const noexcept { return std::isfinite(Min.x) && std::isfinite(Min.y) && std::isfinite(Max.x) && std::isfinite(Max.y) && Min.x < Max.x && Min.y < Max.y; }
};
inline bool IsValidThickness(float t) noexcept { return std::isfinite(t) && t >= 0.1f && t <= 20; }
inline bool IsFinitePoint(ImVec2 p) noexcept { return std::isfinite(p.x) && std::isfinite(p.y); }
inline void DrawLine(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 c, float t = 1) {
    if (!dl || !IsValidThickness(t) || !IsFinitePoint(a) || !IsFinitePoint(b)) return;
    const float dx = b.x - a.x, dy = b.y - a.y;
    if (dx * dx + dy * dy >= 0.0001f) dl->AddLine(a, b, c, t);
}
inline void DrawOutlinedRect(ImDrawList* dl, const Rect& r, ImU32 c, float t = 1) {
    if (dl && r.IsValid() && IsValidThickness(t)) dl->AddRect(r.Min, r.Max, c, 0, 0, t);
}
class EnhancedOptimizer final {
    Optimizer optimizer_;
public:
    void BeginFrame() noexcept { optimizer_.BeginFrame(); }
    const PerformanceStats& GetStats() const noexcept { return optimizer_.GetStats(); }
};
}
static NO7::UI::Extended::EnhancedOptimizer g_optimizer;

#define NO7_CONFIG_FIELDS(X) \
 X(bool, visualEnabled, 1, 0, 1) X(bool, visualBox, 1, 0, 1) X(bool, visualNodes, 0, 0, 1) \
 X(bool, visualDistance, 0, 0, 1) X(bool, visualSelf, 0, 0, 1) X(bool, visualLines, 1, 0, 1) \
 X(bool, visualHealth, 1, 0, 1) X(bool, visualName, 1, 0, 1) \
 X(bool, trackingEnabled, 0, 0, 1) X(bool, showTrackingRange, 1, 0, 1) X(bool, checkVisibility, 0, 0, 1) \
 X(float, trackingRange, 150.0f, 10, 400) X(float, trackingSmooth, 12.0f, 5, 20) X(bool, stabilization, 0, 0, 1) \
 X(float, maxRenderDist, 500.0f, 0, 1000) X(float, boxThickness, 1.5f, .5f, 5) X(float, nodeThickness, 1.0f, .5f, 5)

struct FrameworkConfig {
    bool menuOpen = false;
#define NO7_MEMBER(type, name, initial, low, high) type name = initial;
    NO7_CONFIG_FIELDS(NO7_MEMBER)
#undef NO7_MEMBER
    float colTarget[4] = {1, .2f, .2f, 1};
    float colFriendly[4] = {.2f, 1, .4f, 1};
};

#define NO7_OFFSET_FIELDS(X) \
 X(uintptr_t, OBJ_POSITION, 0x5A4, 16, 0, 0x10000000) \
 X(uintptr_t, OBJ_GROUP, 0x17DA4, 16, 0, 0x10000000) \
 X(uintptr_t, OBJ_NODE_PTR, 0x450, 16, 0, 0x10000000) \
 X(uintptr_t, NODE_MODEL, 0x17A8, 16, 0, 0x10000000) \
 X(uintptr_t, MODEL_NODE_ARRAY, 0x18, 16, 0, 0x10000000) \
 X(uintptr_t, MODEL_NODE_COUNT, 0x20, 16, 0, 0x10000000) \
 X(uintptr_t, NODE_STRIDE, 64, 10, 1, 0x10000000) \
 X(int, NODE_INDEX_TOP, 6, 10, 0, 65535) \
 X(int, NODE_INDEX_MID, 5, 10, 0, 65535) \
 X(int, NODE_INDEX_BOTTOM, 0, 10, 0, 65535) \
 X(uintptr_t, HEALTH_OFFSET, 0x0, 16, 0, 0x10000000) \
 X(uintptr_t, MAX_HEALTH_OFFSET, 0x0, 16, 0, 0x10000000) \
 X(uintptr_t, NAME_OFFSET, 0x0, 16, 0, 0x10000000) \
 X(bool, NAME_IS_POINTER, false, 10, 0, 1) \
 X(uintptr_t, ENGINE_RAY_OBJ, 0x11FEFA0, 16, 0, 0x10000000) \
 X(uintptr_t, WORLD_INTERSECTION_METHOD, 0x5D150, 16, 0, 0x10000000) \
 X(int, RAY_OBJECT_MODULE, 1, 10, 0, 2) \
 X(int, WORLD_INTERSECTION_MODULE, 2, 10, 0, 2) \
 X(bool, RAY_OBJECT_IS_POINTER, true, 10, 0, 1) \
 X(int, RAYCAST_SIGNATURE_MODE, 0, 10, 0, 2)

namespace TargetProcess {
    constexpr ObfuscatedString OBF_PROC_NAME("crossfire.exe");
    constexpr auto MOD_EXE = OBF_PROC_NAME;
    constexpr const wchar_t* MOD_CORE = L"CShell_x64.dll";
    constexpr uintptr_t MODULE_ROOT     = 0x5B1EEA0;
    constexpr uintptr_t ROOT_SLOTS      = 0x10;
    constexpr uintptr_t ROOT_CAMERA     = 0x168;
    constexpr uintptr_t ROOT_LOCAL_OBJ  = 0x1198;
    constexpr uintptr_t SLOT_STRIDE     = 0x8;
    constexpr uintptr_t SLOT_COUNT      = 0x1F;
    constexpr uintptr_t CAM_ROT_X       = 0x6C;
    constexpr uintptr_t CAM_ROT_Y       = 0x184;
    constexpr uintptr_t SETTER_ROT_X    = 0x13F6DA0;
    constexpr uintptr_t SETTER_ROT_Y    = 0x13F6D20;
    constexpr uintptr_t RECOIL_OFFSET_X = 0x15F8;
    constexpr uintptr_t RECOIL_OFFSET_Y = 0x15FC;
    constexpr uintptr_t LOCAL_POS_OFFSET = 0x3CC;
    constexpr uintptr_t STATE_MATRIX    = 0x11A6BC0;
    constexpr uintptr_t VIEW_MATRIX     = 0x2C70;
    constexpr uintptr_t SWAP_CHAIN_PTR  = 0x11CAAF8;

#define NO7_DEFAULT(type, name, initial, base, low, high) constexpr type DEFAULT_##name = initial;
    NO7_OFFSET_FIELDS(NO7_DEFAULT)
#undef NO7_DEFAULT

    inline uintptr_t OBJ_POSITION = DEFAULT_OBJ_POSITION;
    inline uintptr_t OBJ_GROUP = DEFAULT_OBJ_GROUP;
    inline uintptr_t OBJ_NODE_PTR = DEFAULT_OBJ_NODE_PTR;
    inline uintptr_t NODE_MODEL = DEFAULT_NODE_MODEL;
    inline uintptr_t MODEL_NODE_ARRAY = DEFAULT_MODEL_NODE_ARRAY;
    inline uintptr_t MODEL_NODE_COUNT = DEFAULT_MODEL_NODE_COUNT;
    inline uintptr_t NODE_STRIDE = DEFAULT_NODE_STRIDE;
    inline int NODE_INDEX_TOP = DEFAULT_NODE_INDEX_TOP;
    inline int NODE_INDEX_MID = DEFAULT_NODE_INDEX_MID;
    inline int NODE_INDEX_BOTTOM = DEFAULT_NODE_INDEX_BOTTOM;
    inline uintptr_t HEALTH_OFFSET = DEFAULT_HEALTH_OFFSET;
    inline uintptr_t MAX_HEALTH_OFFSET = DEFAULT_MAX_HEALTH_OFFSET;
    inline uintptr_t NAME_OFFSET = DEFAULT_NAME_OFFSET;
    inline bool NAME_IS_POINTER = DEFAULT_NAME_IS_POINTER;
    inline uintptr_t ENGINE_RAY_OBJ = DEFAULT_ENGINE_RAY_OBJ;
    inline uintptr_t WORLD_INTERSECTION_METHOD = DEFAULT_WORLD_INTERSECTION_METHOD;
    inline int RAY_OBJECT_MODULE = DEFAULT_RAY_OBJECT_MODULE;
    inline int WORLD_INTERSECTION_MODULE = DEFAULT_WORLD_INTERSECTION_MODULE;
    inline bool RAY_OBJECT_IS_POINTER = DEFAULT_RAY_OBJECT_IS_POINTER;
    inline int RAYCAST_SIGNATURE_MODE = DEFAULT_RAYCAST_SIGNATURE_MODE;

    inline uintptr_t RAY_OBJECT_ABSOLUTE = 0;
    inline uintptr_t WORLD_INTERSECTION_ABSOLUTE = 0;
}

struct ParsedOffsets {
#define NO7_MEMBER(type, name, initial, base, low, high) type name = TargetProcess::DEFAULT_##name;
    NO7_OFFSET_FIELDS(NO7_MEMBER)
#undef NO7_MEMBER
};

static ParsedOffsets captureOffsets() noexcept {
    ParsedOffsets out;
#define NO7_CAPTURE(type, name, initial, base, low, high) out.name = TargetProcess::name;
    NO7_OFFSET_FIELDS(NO7_CAPTURE)
#undef NO7_CAPTURE
    return out;
}

static void swapOffsets(ParsedOffsets& value) noexcept {
#define NO7_SWAP(type, name, initial, base, low, high) std::swap(TargetProcess::name, value.name);
    NO7_OFFSET_FIELDS(NO7_SWAP)
#undef NO7_SWAP
}

struct Vec3 { float x, y, z; };
struct Mat4 { float m[4][4]; };
struct ScreenPoint { float x = 0, y = 0; bool valid = false; };
static Vec3 operator-(const Vec3& a, const Vec3& b) noexcept { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
static float len3(const Vec3& v) noexcept { return std::hypot(v.x, v.y, v.z); }
static bool finiteVec(const Vec3& v) noexcept { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

static bool worldToScreen(const Vec3& p, const Mat4& m, int sw, int sh, float& sx, float& sy) {
    const float x = p.x*m.m[0][0] + p.y*m.m[1][0] + p.z*m.m[2][0] + m.m[3][0];
    const float y = p.x*m.m[0][1] + p.y*m.m[1][1] + p.z*m.m[2][1] + m.m[3][1];
    const float w = p.x*m.m[0][3] + p.y*m.m[1][3] + p.z*m.m[2][3] + m.m[3][3];
    if (sw <= 0 || sh <= 0 || !std::isfinite(x) || !std::isfinite(y) || !std::isfinite(w) || w < 0.01f) return false;
    sx = sw * 0.5f * (1 + x / w);
    sy = sh * 0.5f * (1 - y / w);
    return std::isfinite(sx) && std::isfinite(sy);
}

inline void WorldToScreen4(const Vec3 (&p)[4], const Mat4& m, int sw, int sh, ScreenPoint (&out)[4]) noexcept {
    for (auto& v : out) v = {};
    if (sw <= 0 || sh <= 0) return;
    const __m128 px = _mm_setr_ps(p[0].x, p[1].x, p[2].x, p[3].x);
    const __m128 py = _mm_setr_ps(p[0].y, p[1].y, p[2].y, p[3].y);
    const __m128 pz = _mm_setr_ps(p[0].z, p[1].z, p[2].z, p[3].z);
    const auto project = [&](int c) {
        __m128 v = _mm_mul_ps(px, _mm_set1_ps(m.m[0][c]));
        v = _mm_add_ps(v, _mm_mul_ps(py, _mm_set1_ps(m.m[1][c])));
        v = _mm_add_ps(v, _mm_mul_ps(pz, _mm_set1_ps(m.m[2][c])));
        return _mm_add_ps(v, _mm_set1_ps(m.m[3][c]));
    };
    const auto finite = [](__m128 v) { return _mm_cmple_ps(_mm_andnot_ps(_mm_set1_ps(-0.0f), v), _mm_set1_ps((std::numeric_limits<float>::max)())); };
    const __m128 x = project(0), y = project(1), w = project(3), one = _mm_set1_ps(1);
    __m128 valid = _mm_and_ps(_mm_cmpge_ps(w, _mm_set1_ps(0.01f)), finite(w));
    valid = _mm_and_ps(valid, _mm_and_ps(finite(x), finite(y)));
    const __m128 safeW = _mm_or_ps(_mm_and_ps(valid, w), _mm_andnot_ps(valid, one));
    const __m128 inv = _mm_div_ps(one, safeW);
    const __m128 sx = _mm_mul_ps(_mm_set1_ps(sw * 0.5f), _mm_add_ps(one, _mm_mul_ps(_mm_and_ps(valid, x), inv)));
    const __m128 sy = _mm_mul_ps(_mm_set1_ps(sh * 0.5f), _mm_sub_ps(one, _mm_mul_ps(_mm_and_ps(valid, y), inv)));
    valid = _mm_and_ps(valid, _mm_and_ps(finite(sx), finite(sy)));
    alignas(16) float xs[4], ys[4];
    _mm_store_ps(xs, sx); _mm_store_ps(ys, sy);
    const int mask = _mm_movemask_ps(valid);
    for (int i = 0; i < 4; ++i) if (mask & (1 << i)) out[i] = {xs[i], ys[i], true};
}

static double fastAtan2(double y, double x) noexcept {
    constexpr double pi = 3.14159265358979323846;
    constexpr double halfPi = pi * 0.5;
    const double ax = std::fabs(x);
    const double ay = std::fabs(y);
    if (ax == 0.0 && ay == 0.0) return std::copysign(std::signbit(x) ? pi : 0.0, y);
    const bool swapAxes = ay > ax;
    const double z = swapAxes ? ax / ay : ay / ax;
    const double z2 = z * z;
    double angle = z * (0.9998660 + z2 * (-0.3302995 + z2 * (0.1801410 + z2 * (-0.0851330 + z2 * 0.0208351))));
    if (swapAxes) angle = halfPi - angle;
    if (std::signbit(x)) angle = pi - angle;
    return std::copysign(angle, y);
}

static Vec3 calcAngle(const Vec3& src, const Vec3& dst) {
    if (!finiteVec(src) || !finiteVec(dst)) return {};
    const double dx = static_cast<double>(dst.x) - src.x;
    const double dy = static_cast<double>(dst.y) - src.y;
    const double dz = static_cast<double>(dst.z) - src.z;
    const double horizontal = std::sqrt(dx * dx + dy * dy);
    constexpr double degrees = 180.0 / 3.14159265358979323846;
    return {
        static_cast<float>(-fastAtan2(dz, horizontal) * degrees),
        static_cast<float>( fastAtan2(dy, dx) * degrees),
        0.0f
    };
}

static FrameworkConfig g_cfg;
struct TrackedObject {
    uintptr_t ptr = 0;
    Vec3 pos{}, topPos{}, nodeMid{}, nodeBot{};
    bool hasNodes = false;
    int groupId = 0;
    float distance = 0;
    float health = 100.0f, maxHealth = 100.0f;
    char name[32] = "Target";
    bool valid = false;
    bool visible = false;
};
struct FrameSnapshot {
    std::vector<TrackedObject> objects;
    Vec3 localPos{};
    bool localPosOk = false;
    int localGroupId = 0;
    bool localGroupOk = false;
    Mat4 viewMatrix{};
    float camRotX = 0, camRotY = 0;
    uintptr_t localPtr = 0, cameraPtr = 0;
    bool matrixOk = false, cameraAnglesOk = false;
    std::chrono::steady_clock::time_point collectedAt{};
};
enum FrameworkState : LONG { Dormant, Initializing, Running, Stopping, Stopped, Failed };
static std::atomic<LONG> g_state{Dormant};
static std::atomic<bool> g_running{false}, g_workerDone{true}, g_graphicsDone{true};
static HMODULE g_module = nullptr;
static HANDLE g_initThreadHandle = nullptr;
static std::thread g_dataThread;
static HANDLE g_targetProcess = nullptr;
static DWORD g_targetPid = 0;
static uintptr_t g_exeBase = 0, g_coreBase = 0;
static std::mutex g_snapMtx;
static std::recursive_mutex g_uiMtx;
static FrameSnapshot g_snapFront, g_snapBack;
static IDXGISwapChain* g_swap = nullptr;
static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static ID3D11RenderTargetView* g_rtv = nullptr;
static HWND g_hwnd = nullptr;
static WNDPROC g_origWndProc = nullptr;
static ImGuiContext* g_imguiContext = nullptr;
static bool g_imguiReady = false;
using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);
using ResizeFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
static PresentFn g_origPresent = nullptr;
static ResizeFn g_origResize = nullptr;
static void** g_originalVtbl = nullptr;
static void** g_hookedVtbl = nullptr;

static void RequestFrameworkStop() noexcept {
    LONG expected = Running;
    g_state.compare_exchange_strong(expected, Stopping);
    expected = Initializing;
    g_state.compare_exchange_strong(expected, Stopping);
    g_running.store(false);
}

static void configLog(const char* key, const char* reason) noexcept {
    char message[384]{};
    std::snprintf(message, sizeof(message), "NO7: %s: %s\n", key, reason);
    OutputDebugStringA(message);
}

static bool sameFrameworkConfig(const FrameworkConfig& a, const FrameworkConfig& b) noexcept {
    if (a.menuOpen != b.menuOpen) return false;
#define NO7_COMPARE(type, name, initial, low, high) if (a.name != b.name) return false;
    NO7_CONFIG_FIELDS(NO7_COMPARE)
#undef NO7_COMPARE
    for (int i = 0; i < 4; ++i) if (a.colTarget[i] != b.colTarget[i] || a.colFriendly[i] != b.colFriendly[i]) return false;
    return true;
}

static std::shared_ptr<const FrameworkConfig>& configPublication() {
    static std::shared_ptr<const FrameworkConfig> value;
    return value;
}

static std::shared_ptr<const FrameworkConfig>& frameConfigStorage() {
    static thread_local std::shared_ptr<const FrameworkConfig> value;
    return value;
}

static std::shared_ptr<const FrameworkConfig> acquirePublishedConfig() {
    auto value = std::atomic_load_explicit(&configPublication(), std::memory_order_acquire);
    if (!value) {
        static const auto defaults = std::make_shared<const FrameworkConfig>();
        return defaults;
    }
    return value;
}

static std::shared_ptr<const FrameworkConfig> acquireFrameConfig() {
    const auto& pinned = frameConfigStorage();
    return pinned ? pinned : acquirePublishedConfig();
}

static void publishFrameworkConfig(const FrameworkConfig& value) {
    auto previous = std::atomic_load_explicit(&configPublication(), std::memory_order_acquire);
    if (!previous || !sameFrameworkConfig(*previous, value)) {
        auto next = std::make_shared<const FrameworkConfig>(value);
        std::atomic_store_explicit(&configPublication(), next, std::memory_order_release);
        frameConfigStorage() = std::move(next);
    } else {
        frameConfigStorage() = std::move(previous);
    }
}

static void commitUiConfig(const FrameworkConfig& draft) {
    publishFrameworkConfig(draft);
    g_cfg = draft;
}

static bool validateFrameworkConfig(const FrameworkConfig& value) noexcept {
    bool valid = true;
#define NO7_VALIDATE(type, name, initial, low, high) \
    if (!std::isfinite(static_cast<double>(value.name)) || static_cast<double>(value.name) < (low) || static_cast<double>(value.name) > (high)) { \
        configLog(#name, "configuracao fora da faixa"); valid = false; \
    }
    NO7_CONFIG_FIELDS(NO7_VALIDATE)
#undef NO7_VALIDATE
    for (int i = 0; i < 4; ++i) {
        if (!std::isfinite(value.colTarget[i]) || value.colTarget[i] < 0 || value.colTarget[i] > 1) {
            configLog("colTarget", "componente fora da faixa"); valid = false;
        }
        if (!std::isfinite(value.colFriendly[i]) || value.colFriendly[i] < 0 || value.colFriendly[i] > 1) {
            configLog("colFriendly", "componente fora da faixa"); valid = false;
        }
    }
    return valid;
}

static std::string trimIni(std::string text) {
    const auto first = text.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = text.find_last_not_of(" \t\r\n");
    return text.substr(first, last - first + 1);
}

static bool parseIniUnsigned(const std::string& text, int base, bool boolean, uint64_t& out) noexcept {
    if (boolean) {
        if (text == "true" || text == "TRUE") { out = 1; return true; }
        if (text == "false" || text == "FALSE") { out = 0; return true; }
    }
    if (text.empty() || text[0] == '-' || text[0] == '+') return false;
    try {
        size_t end = 0;
        const auto value = std::stoull(text, &end, base);
        if (end != text.size()) return false;
        out = value;
        return true;
    } catch (...) { return false; }
}

static bool iniUnsignedInRange(uint64_t value, uint64_t low, uint64_t high) noexcept {
    return value >= low && value <= high;
}

static bool parseOffsetsIni(std::istream& input, ParsedOffsets& out) {
    ParsedOffsets candidate;
    std::set<std::string> seen;
    std::string line;
    bool valid = true;
    bool inOffsets = false;
    size_t totalBytes = 0;

    while (std::getline(input, line)) {
        totalBytes += line.size();
        if (line.size() > 4096 || totalBytes > 65536) {
            configLog("offsets.ini", "arquivo/linha excede limite; defaults");
            out = ParsedOffsets{};
            return false;
        }
        line = trimIni(std::move(line));
        if (line.empty() || line[0] == ';' || line[0] == '#') continue;
        if (line[0] == '[') {
            inOffsets = line == "[Offsets]";
            if (!inOffsets) { configLog("offsets.ini", "secao desconhecida"); valid = false; }
            continue;
        }
        const auto equals = line.find('=');
        if (!inOffsets || equals == std::string::npos) {
            configLog("offsets.ini", "linha sem chave/valor ou fora da secao"); valid = false; continue;
        }
        const std::string key = trimIni(line.substr(0, equals));
        const std::string text = trimIni(line.substr(equals + 1));
        if (!seen.insert(key).second) { configLog(key.c_str(), "chave duplicada"); valid = false; continue; }
        uint64_t value = 0;
#define NO7_PARSE(type, name, initial, radix, low, high) \
        if (key == #name) { \
            if (!parseIniUnsigned(text, radix, std::is_same_v<type, bool>, value) || \
                !iniUnsignedInRange(value, static_cast<uint64_t>(low), static_cast<uint64_t>(high))) { \
                configLog(#name, "conversao invalida ou fora da faixa"); valid = false; \
            } else { candidate.name = static_cast<type>(value); } \
        } else
        NO7_OFFSET_FIELDS(NO7_PARSE)
        { configLog(key.c_str(), "chave desconhecida"); valid = false; }
#undef NO7_PARSE
    }
    if (input.bad() || seen.empty()) { configLog("offsets.ini", "falha de leitura ou arquivo sem campos"); valid = false; }
    if (!valid) { out = ParsedOffsets{}; configLog("offsets.ini", "transacao rejeitada; defaults restaurados"); return false; }
    if (candidate.HEALTH_OFFSET != 0 && candidate.MAX_HEALTH_OFFSET == 0) {
        configLog("HEALTH_OFFSET", "sem MAX_HEALTH_OFFSET; ambos desativados");
        candidate.HEALTH_OFFSET = 0; candidate.MAX_HEALTH_OFFSET = 0;
    }
    out = candidate;
    return true;
}

static bool parseFrameworkConfig(std::istream& input, FrameworkConfig& out) {
    FrameworkConfig candidate;
    input.imbue(std::locale::classic());
    bool extracted = true;
#define NO7_READ(type, name, initial, low, high) if (!(input >> candidate.name)) { configLog(#name, "campo ausente ou invalido"); extracted = false; }
    NO7_CONFIG_FIELDS(NO7_READ)
#undef NO7_READ
    for (float& c : candidate.colTarget) if (!(input >> c)) { configLog("colTarget", "componente ausente ou invalido"); extracted = false; }
    for (float& c : candidate.colFriendly) if (!(input >> c)) { configLog("colFriendly", "componente ausente ou invalido"); extracted = false; }
    bool trailing = false;
    if (extracted) { input >> std::ws; trailing = input.peek() != std::char_traits<char>::eof(); }
    const bool fieldsValid = validateFrameworkConfig(candidate);
    if (!extracted || trailing || input.bad() || !fieldsValid) {
        configLog("config.ini", "transacao rejeitada; defaults restaurados"); out = FrameworkConfig{}; return false;
    }
    out = candidate;
    return true;
}

void LoadConfig() {
    FrameworkConfig parsedConfig;
    ParsedOffsets parsedOffsets;
    try {
        std::ifstream config("C:\\Windows\\Temp\\no7_config.ini");
        if (config.is_open()) parseFrameworkConfig(config, parsedConfig);
        std::ifstream offsets("C:\\Windows\\Temp\\no7_offsets.ini");
        if (offsets.is_open()) parseOffsetsIni(offsets, parsedOffsets);
    } catch (...) {
        configLog("LoadConfig", "excecao; defaults restaurados");
        parsedConfig = FrameworkConfig{};
        parsedOffsets = ParsedOffsets{};
    }
    publishFrameworkConfig(parsedConfig);
    g_cfg = parsedConfig;
    swapOffsets(parsedOffsets);
}

static bool writeConfigFileAtomically(const wchar_t* destination, const std::string& content) {
    static std::atomic<uint64_t> sequence{0};
    const std::wstring temporary = std::wstring(destination) + L"." + std::to_wstring(GetCurrentProcessId()) + L"." + std::to_wstring(sequence.fetch_add(1)) + L".tmp";
    HANDLE file = CreateFileW(temporary.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;
    bool ok = true;
    size_t offset = 0;
    while (offset < content.size()) {
        const DWORD amount = static_cast<DWORD>(std::min<size_t>(content.size() - offset, 0x40000000));
        DWORD written = 0;
        if (!WriteFile(file, content.data() + offset, amount, &written, nullptr) || written == 0) { ok = false; break; }
        offset += written;
    }
    if (ok && !FlushFileBuffers(file)) ok = false;
    if (!CloseHandle(file)) ok = false;
    if (ok) ok = MoveFileExW(temporary.c_str(), destination, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) != FALSE;
    if (!ok) DeleteFileW(temporary.c_str());
    return ok;
}

void SaveConfig() {
    try {
        const FrameworkConfig config = g_cfg;
        const ParsedOffsets offsets = captureOffsets();
        if (!validateFrameworkConfig(config)) { configLog("SaveConfig", "configuracao invalida; escrita cancelada"); return; }
        std::ostringstream values;
        values.imbue(std::locale::classic());
        values << std::setprecision(std::numeric_limits<float>::max_digits10);
#define NO7_WRITE(type, name, initial, low, high) values << config.name << ' ';
        NO7_CONFIG_FIELDS(NO7_WRITE)
#undef NO7_WRITE
        values << '\n';
        for (float c : config.colTarget) values << c << ' ';
        values << '\n';
        for (float c : config.colFriendly) values << c << ' ';
        values << '\n';

        std::ostringstream addresses;
        addresses.imbue(std::locale::classic());
        addresses << "[Offsets]\n";
#define NO7_WRITE_OFFSET(type, name, initial, radix, low, high) \
        addresses << #name "=" << std::setbase(radix) << static_cast<uint64_t>(offsets.name) << '\n';
        NO7_OFFSET_FIELDS(NO7_WRITE_OFFSET)
#undef NO7_WRITE_OFFSET
        if (!values || !addresses) { configLog("SaveConfig", "falha na serializacao"); return; }
        if (!writeConfigFileAtomically(L"C:\\Windows\\Temp\\no7_config.ini", values.str()))
            configLog("config.ini", "falha na substituicao do arquivo");
        if (!writeConfigFileAtomically(L"C:\\Windows\\Temp\\no7_offsets.ini", addresses.str()))
            configLog("offsets.ini", "falha na substituicao do arquivo");
    } catch (...) {
        configLog("SaveConfig", "excecao contida; confira os arquivos");
    }
}

template<typename T> static void releaseCOM(T*& p) noexcept { if (p) { p->Release(); p = nullptr; } }
template<typename T> static bool tryRead(uintptr_t addr, T& out) noexcept {
    static_assert(std::is_trivially_copyable_v<T>, "Invalid memory-read type.");
    out = T{};
    if (!addr || !g_targetProcess || addr > (std::numeric_limits<uintptr_t>::max)() - (sizeof(T) - 1)) return false;
    T value{}; SIZE_T got = 0;
    if (!ReadProcessMemory(g_targetProcess, reinterpret_cast<LPCVOID>(addr), &value, sizeof(value), &got) || got != sizeof(value)) return false;
    out = value;
    return true;
}
template<typename T> static T rpm(uintptr_t addr) noexcept { T v{}; tryRead(addr, v); return v; }

static bool checkedAddress(uintptr_t base, uintptr_t offset, uintptr_t& address) noexcept {
    address = 0;
    if (!base || base > (std::numeric_limits<uintptr_t>::max)() - offset) return false;
    address = base + offset;
    return true;
}

static bool readFiniteEntityFloat(uintptr_t object, uintptr_t offset, float& value) noexcept {
    value = 0.0f;
    uintptr_t address = 0;
    return offset != 0 && checkedAddress(object, offset, address) && tryRead(address, value) && std::isfinite(value);
}

template<size_t N>
static bool readBoundedEntityString(uintptr_t address, char (&out)[N]) noexcept {
    static_assert(N > 0, "String buffer must include terminator.");
    std::memset(out, 0, sizeof(out));
    if (!address) return false;
    for (size_t i = 0; i + 1 < N; ++i) {
        uintptr_t cur = 0;
        char ch = '\0';
        if (!checkedAddress(address, static_cast<uintptr_t>(i), cur) || !tryRead(cur, ch)) {
            std::memset(out, 0, sizeof(out));
            return false;
        }
        out[i] = ch;
        if (ch == '\0') return true;
    }
    out[N - 1] = '\0';
    return true;
}

static bool cachedEntityName(uintptr_t object, int groupId, char (&out)[32]) noexcept {
    using Clock = std::chrono::steady_clock;
    struct Entry {
        uintptr_t object = 0;
        uintptr_t nameOffset = 0;
        int group = 0;
        bool indirect = false;
        bool occupied = false;
        bool readOk = false;
        char text[32]{};
        Clock::time_point expires{};
        uint64_t lastUse = 0;
    };
    static std::array<Entry, 64> entries{};
    static uint64_t usage = 0;
    std::memset(out, 0, sizeof(out));
    if (!object || !TargetProcess::NAME_OFFSET) return false;

    Entry* found = nullptr;
    Entry* oldest = &entries.front();
    for (auto& entry : entries) {
        if (entry.occupied && entry.object == object) { found = &entry; break; }
        if (entry.lastUse < oldest->lastUse) oldest = &entry;
    }
    const auto now = Clock::now();
    if (!found) found = oldest;
    const bool refresh = !found->occupied || found->object != object ||
        found->group != groupId || now >= found->expires ||
        found->nameOffset != TargetProcess::NAME_OFFSET ||
        found->indirect != TargetProcess::NAME_IS_POINTER;

    if (refresh) {
        *found = Entry{};
        found->occupied = true;
        found->object = object;
        found->group = groupId;
        found->nameOffset = TargetProcess::NAME_OFFSET;
        found->indirect = TargetProcess::NAME_IS_POINTER;
        uintptr_t address = 0;
        if (checkedAddress(object, found->nameOffset, address)) {
            bool addressOk = true;
            if (found->indirect) {
                uintptr_t pointer = 0;
                addressOk = tryRead(address, pointer) && pointer != 0;
                address = pointer;
            }
            if (addressOk) found->readOk = readBoundedEntityString(address, found->text);
        }
        found->expires = Clock::now() + std::chrono::milliseconds(250);
    }
    found->lastUse = ++usage;
    std::memcpy(out, found->text, sizeof(out));
    return found->readOk;
}

static void readEntityMetadata(TrackedObject& obj) noexcept {
    obj.health = 0.0f;
    obj.maxHealth = 1.0f;
    std::memset(obj.name, 0, sizeof(obj.name));
    float hp = 0.0f, maximum = 0.0f;
    const bool hpOk = readFiniteEntityFloat(obj.ptr, TargetProcess::HEALTH_OFFSET, hp);
    const bool maxOk = readFiniteEntityFloat(obj.ptr, TargetProcess::MAX_HEALTH_OFFSET, maximum);
    if (hpOk && maxOk && hp >= 0 && maximum > 0) {
        obj.maxHealth = maximum;
        obj.health = std::clamp(hp, 0.0f, maximum);
    }
    cachedEntityName(obj.ptr, obj.groupId, obj.name);
}

static bool readNodePos(uintptr_t obj, int index, Vec3& out) {
    out = {};
    const uintptr_t node = rpm<uintptr_t>(obj + TargetProcess::OBJ_NODE_PTR);
    if (!node) return false;
    const uintptr_t model = rpm<uintptr_t>(node + TargetProcess::NODE_MODEL);
    if (!model) return false;
    const uintptr_t nodes = rpm<uintptr_t>(model + TargetProcess::MODEL_NODE_ARRAY);
    int count = 0;
    if (!nodes || !tryRead(model + TargetProcess::MODEL_NODE_COUNT, count) || index < 0 || index >= count) return false;
    const uintptr_t offset = static_cast<uintptr_t>(index) * TargetProcess::NODE_STRIDE;
    if (nodes > (std::numeric_limits<uintptr_t>::max)() - offset) return false;
    return tryRead(nodes + offset, out) && finiteVec(out);
}

static uintptr_t configuredRayModule(int module) noexcept {
    switch (module) { case 1: return g_exeBase; case 2: return g_coreBase; default: return 0; }
}

static bool raycastCall(int mode, uintptr_t method, uintptr_t rayObj, const Vec3& start, const Vec3& end, bool& blocked) {
    if (mode == 1) {
        using Fn = bool(__thiscall*)(void*, Vec3, Vec3);
        const auto fn = reinterpret_cast<Fn>(method);
        __try { blocked = fn(reinterpret_cast<void*>(rayObj), start, end); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    if (mode == 2) {
        using Fn = bool(__thiscall*)(void*, Vec3*, Vec3*);
        const auto fn = reinterpret_cast<Fn>(method);
        Vec3 s = start, e = end;
        __try { blocked = fn(reinterpret_cast<void*>(rayObj), &s, &e); return true; }
        __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
    }
    return false;
}

static void resolveRaycastAddresses() {
    const uintptr_t objectBase = configuredRayModule(TargetProcess::RAY_OBJECT_MODULE);
    const uintptr_t methodBase = configuredRayModule(TargetProcess::WORLD_INTERSECTION_MODULE);
    uintptr_t absObj = 0, absMeth = 0;
    if (checkedAddress(objectBase, TargetProcess::ENGINE_RAY_OBJ, absObj))
        TargetProcess::RAY_OBJECT_ABSOLUTE = absObj;
    if (checkedAddress(methodBase, TargetProcess::WORLD_INTERSECTION_METHOD, absMeth))
        TargetProcess::WORLD_INTERSECTION_ABSOLUTE = absMeth;
}

static bool isVisible(const FrameSnapshot& s, const Vec3& targetPos) {
    const auto configuration = acquireFrameConfig();
    const FrameworkConfig& cfg = *configuration;
    if (!cfg.checkVisibility) return true;
    if (!s.localPosOk || !finiteVec(s.localPos) || !finiteVec(targetPos)) return true;
    uintptr_t rayObj = TargetProcess::RAY_OBJECT_ABSOLUTE;
    const uintptr_t method = TargetProcess::WORLD_INTERSECTION_ABSOLUTE;
    if (!rayObj || !method) return true;
    if (TargetProcess::RAY_OBJECT_IS_POINTER) {
        uintptr_t deref = 0;
        if (!tryRead(rayObj, deref) || !deref) return true;
        rayObj = deref;
    }
    bool blocked = false;
    if (TargetProcess::RAYCAST_SIGNATURE_MODE == 1) {
        return raycastCall(1, method, rayObj, s.localPos, targetPos, blocked) ? !blocked : true;
    }
    if (TargetProcess::RAYCAST_SIGNATURE_MODE == 2) {
        return raycastCall(2, method, rayObj, s.localPos, targetPos, blocked) ? !blocked : true;
    }
    if (raycastCall(1, method, rayObj, s.localPos, targetPos, blocked)) return !blocked;
    if (raycastCall(2, method, rayObj, s.localPos, targetPos, blocked)) return !blocked;
    return true;
}

class Telemetry60HzPacer final {
    using Clock = std::chrono::steady_clock;
    HANDLE timer_ = nullptr;
    Clock::time_point epoch_ = Clock::now();
    uint64_t tick_ = 0;
public:
    Telemetry60HzPacer() noexcept {
        constexpr DWORD highResolution = 0x00000002;
        timer_ = CreateWaitableTimerExW(nullptr, nullptr, highResolution, TIMER_MODIFY_STATE | SYNCHRONIZE);
        if (!timer_) timer_ = CreateWaitableTimerExW(nullptr, nullptr, 0, TIMER_MODIFY_STATE | SYNCHRONIZE);
    }
    ~Telemetry60HzPacer() { if (timer_) { CancelWaitableTimer(timer_); CloseHandle(timer_); } }
    void WaitNext() {
        const auto now = Clock::now();
        ++tick_;
        const double elapsed = std::chrono::duration<double>(now - epoch_).count();
        const uint64_t nextFutureTick = static_cast<uint64_t>(elapsed * 60.0) + 1;
        tick_ = std::max(tick_, nextFutureTick);
        const auto deadline = epoch_ + std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(static_cast<double>(tick_) / 60.0));
        const auto remaining = deadline - Clock::now();
        if (remaining <= Clock::duration::zero()) return;
        if (timer_) {
            const auto ns = std::chrono::duration_cast<std::chrono::nanoseconds>(remaining).count();
            LARGE_INTEGER due{};
            due.QuadPart = -std::max<LONGLONG>(1, static_cast<LONGLONG>((ns + 99) / 100));
            if (SetWaitableTimerEx(timer_, &due, 0, nullptr, nullptr, nullptr, 0)) {
                if (WaitForSingleObject(timer_, INFINITE) == WAIT_OBJECT_0) {
                    if (Clock::now() < deadline) std::this_thread::sleep_until(deadline);
                    return;
                }
            }
        }
        std::this_thread::sleep_until(deadline);
    }
};

static void dataCollectionThread() {
    FrameSnapshot snap;
    snap.objects.reserve(TargetProcess::SLOT_COUNT);
    Telemetry60HzPacer pacer;
    while (g_running.load()) {
        snap.collectedAt = std::chrono::steady_clock::now();
        snap.objects.clear();
        snap.localPos = {};
        snap.localPosOk = false;
        snap.localGroupId = 0;
        snap.localGroupOk = false;
        snap.viewMatrix = {};
        snap.matrixOk = false;
        snap.cameraAnglesOk = false;
        snap.camRotX = snap.camRotY = 0;
        snap.localPtr = snap.cameraPtr = 0;
        const uintptr_t root = rpm<uintptr_t>(g_coreBase + TargetProcess::MODULE_ROOT);
        if (root) {
            snap.localPtr = rpm<uintptr_t>(root + TargetProcess::ROOT_LOCAL_OBJ);
            snap.cameraPtr = rpm<uintptr_t>(root + TargetProcess::ROOT_CAMERA);
            const uintptr_t state = rpm<uintptr_t>(g_exeBase + TargetProcess::STATE_MATRIX);
            if (state) {
                snap.matrixOk = tryRead(state + TargetProcess::VIEW_MATRIX, snap.viewMatrix);
                bool nonZero = false;
                for (const auto& row : snap.viewMatrix.m) for (float v : row) {
                    snap.matrixOk = snap.matrixOk && std::isfinite(v);
                    nonZero = nonZero || v != 0;
                }
                snap.matrixOk = snap.matrixOk && nonZero;
            }
            if (snap.cameraPtr) {
                snap.cameraAnglesOk = tryRead(snap.cameraPtr + TargetProcess::CAM_ROT_X, snap.camRotX) &&
                    tryRead(snap.cameraPtr + TargetProcess::CAM_ROT_Y, snap.camRotY) &&
                    std::isfinite(snap.camRotX) && std::isfinite(snap.camRotY);
            }
            if (snap.localPtr) {
                snap.localPosOk = tryRead(snap.localPtr + TargetProcess::LOCAL_POS_OFFSET, snap.localPos) && finiteVec(snap.localPos);
                uintptr_t groupAddress = 0;
                snap.localGroupOk = checkedAddress(snap.localPtr, TargetProcess::OBJ_GROUP, groupAddress) && tryRead(groupAddress, snap.localGroupId);
            }
            for (uintptr_t i = 0; i < TargetProcess::SLOT_COUNT; ++i) {
                const uintptr_t slot = rpm<uintptr_t>(root + TargetProcess::ROOT_SLOTS + i * TargetProcess::SLOT_STRIDE);
                if (!slot) continue;
                TrackedObject obj;
                if (!tryRead(slot + TargetProcess::OBJ_POSITION, obj.pos) || !finiteVec(obj.pos) ||
                    std::fabs(obj.pos.x) > 100000 || std::fabs(obj.pos.y) > 100000 || std::fabs(obj.pos.z) > 100000 ||
                    (obj.pos.x == 0 && obj.pos.y == 0 && obj.pos.z == 0)) continue;
                obj.ptr = slot;
                tryRead(slot + TargetProcess::OBJ_GROUP, obj.groupId);
                if (readNodePos(slot, TargetProcess::NODE_INDEX_TOP, obj.topPos)) {
                    obj.hasNodes = readNodePos(slot, TargetProcess::NODE_INDEX_MID, obj.nodeMid) && readNodePos(slot, TargetProcess::NODE_INDEX_BOTTOM, obj.nodeBot);
                } else obj.topPos = obj.pos;
                obj.distance = snap.localPosOk ? len3(obj.pos - snap.localPos) : 0;
                readEntityMetadata(obj);
                obj.valid = true;
                snap.objects.push_back(obj);
            }
        }
        { std::lock_guard<std::mutex> lock(g_snapMtx); std::swap(snap, g_snapBack); std::swap(g_snapFront, g_snapBack); }
        if (g_running.load()) pacer.WaitNext();
    }
}
static void dataThreadEntry() noexcept {
    try { dataCollectionThread(); } catch (...) { RequestFrameworkStop(); }
    g_workerDone = true;
}
static void copySnapshotForRender(FrameSnapshot& destination) {
    std::lock_guard<std::mutex> lock(g_snapMtx);
    destination = g_snapFront;
}
static bool snapshotFresh(const FrameSnapshot& s) {
    const auto age = std::chrono::steady_clock::now() - s.collectedAt;
    return s.collectedAt.time_since_epoch().count() != 0 && age >= std::chrono::steady_clock::duration::zero() && age <= std::chrono::milliseconds(250);
}

static bool callCameraSetters(uintptr_t camera, float yaw, float pitch) noexcept {
    using SetterFn = void(__fastcall*)(void*, float);
    const auto setY = reinterpret_cast<SetterFn>(g_coreBase + TargetProcess::SETTER_ROT_X);
    const auto setX = reinterpret_cast<SetterFn>(g_coreBase + TargetProcess::SETTER_ROT_Y);
    __try { setY(reinterpret_cast<void*>(camera), yaw); setX(reinterpret_cast<void*>(camera), pitch); return true; }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

static float computeTargetScore(const TrackedObject& e, float screenDx2Dy2, float playerDist, int localGroupId, bool localGroupOk, const FrameworkConfig& cfg) noexcept {
    if (!e.valid || !std::isfinite(screenDx2Dy2) || screenDx2Dy2 < 0 || !std::isfinite(playerDist) || playerDist < 0 || !std::isfinite(cfg.trackingRange) || cfg.trackingRange <= 0)
        return -std::numeric_limits<float>::infinity();
    const double range = cfg.trackingRange;
    const float normalized = static_cast<float>(static_cast<double>(screenDx2Dy2) / (range * range));
    float score = e.visible ? 10000.0f : 0.0f;
    score -= normalized * 0.5f;
    score -= playerDist * 10.0f;
    if (e.visible && localGroupOk && e.groupId != localGroupId) score += 5000.0f;
    const bool healthActive = TargetProcess::HEALTH_OFFSET != 0 && TargetProcess::MAX_HEALTH_OFFSET != 0;
    if (healthActive && e.health <= 0) score -= 20000.0f;
    return score;
}

static void processTracking(const FrameSnapshot& s) {
    const auto configuration = acquireFrameConfig();
    const FrameworkConfig& cfg = *configuration;
    if (!snapshotFresh(s) || !s.localPosOk || !s.cameraPtr || !s.cameraAnglesOk || !s.matrixOk) return;
    const ImVec2 display = ImGui::GetIO().DisplaySize;
    const int sw = static_cast<int>(display.x), sh = static_cast<int>(display.y);
    const TrackedObject* best = nullptr;
    float bestScore = -1e30f;
    for (size_t i = 0; i < s.objects.size(); i += 4) {
        Vec3 positions[4]{}; ScreenPoint points[4];
        const size_t count = std::min<size_t>(4, s.objects.size() - i);
        for (size_t j = 0; j < count; ++j) positions[j] = s.objects[i+j].topPos;
        WorldToScreen4(positions, s.viewMatrix, sw, sh, points);
        for (size_t j = 0; j < count; ++j) {
            if (!points[j].valid || !s.objects[i+j].valid) continue;
            TrackedObject candidate = s.objects[i+j];
            candidate.visible = isVisible(s, candidate.topPos);
            const float dx = points[j].x - sw * 0.5f;
            const float dy = points[j].y - sh * 0.5f;
            const float d2 = dx*dx + dy*dy;
            if (d2 > cfg.trackingRange * cfg.trackingRange) continue;
            const float score = computeTargetScore(candidate, d2, candidate.distance, s.localGroupId, s.localGroupOk, cfg);
            if (score > bestScore) { bestScore = score; best = &s.objects[i+j]; }
        }
    }
    if (!best) return;
    
    static uintptr_t currentTarget = 0;
    static std::chrono::steady_clock::time_point acquireTime;
    static bool hasOvershot = false;
    static std::mt19937 rng(std::random_device{}());
    if (best->ptr != currentTarget) { currentTarget = best->ptr; acquireTime = std::chrono::steady_clock::now(); hasOvershot = false; }
    static std::uniform_int_distribution<int> latencyDist(60, 120);
    const auto timeSinceAcquire = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - acquireTime).count();
    if (timeSinceAcquire < latencyDist(rng)) return;
    
    const Vec3 want = calcAngle(s.localPos, best->topPos);
    float yaw = want.y - s.camRotY, pitch = want.x - s.camRotX;
    const float distance = std::hypot(yaw, pitch);
    if (!std::isfinite(distance) || distance < 0.1f) return;
    
    float baseScale = 1.0f / (std::max(1.0f, cfg.trackingSmooth) * 2.0f);
    float smoothScale = baseScale * baseScale * (3.0f - 2.0f * baseScale);
    if (best->distance < 200.0f) smoothScale *= 0.5f;
    else if (best->distance > 500.0f) smoothScale *= 1.5f;
    
    yaw *= smoothScale; pitch *= smoothScale;
    if (!hasOvershot) { yaw *= 1.10f; pitch *= 1.10f; hasOvershot = true; }
    
    std::normal_distribution<float> noise(0.0f, 0.03f);
    yaw += noise(rng); pitch += noise(rng);
    const float step = std::hypot(yaw, pitch);
    if (step > 3.5f) { yaw *= 3.5f / step; pitch *= 3.5f / step; }
    
    if (!callCameraSetters(s.cameraPtr, s.camRotY + yaw, s.camRotX + pitch)) {
        FrameworkConfig next = cfg;
        next.trackingEnabled = false;
        commitUiConfig(next);
    }
}

static void processStabilization(const FrameSnapshot& s) {
    if (!snapshotFresh(s) || !s.localPtr) return;
    const float zero = 0; SIZE_T x = 0, y = 0;
    WriteProcessMemory(g_targetProcess, reinterpret_cast<void*>(s.localPtr + TargetProcess::RECOIL_OFFSET_X), &zero, sizeof(zero), &x);
    WriteProcessMemory(g_targetProcess, reinterpret_cast<void*>(s.localPtr + TargetProcess::RECOIL_OFFSET_Y), &zero, sizeof(zero), &y);
    if (x != sizeof(zero) || y != sizeof(zero)) {
        const auto configuration = acquireFrameConfig();
        FrameworkConfig next = *configuration;
        next.stabilization = false;
        commitUiConfig(next);
    }
}

struct DistanceLabelCacheEntry {
    uintptr_t object = 0; int bucket = -1; char text[32]{}; ImVec2 size{}; ImFont* font = nullptr; float fontSize = 0; uint64_t lastUse = 0;
};
static const DistanceLabelCacheEntry& cachedDistanceLabel(uintptr_t object, float distance) {
    static DistanceLabelCacheEntry entries[128]{};
    static uint64_t clock = 0;
    const float safe = std::isfinite(distance) ? std::clamp(distance, 0.0f, 100000000.0f) : 0.0f;
    const int bucket = static_cast<int>(std::floor(safe / 5.0f));
    DistanceLabelCacheEntry* entry = nullptr; DistanceLabelCacheEntry* replacement = &entries[0];
    for (auto& c : entries) {
        if (c.object == object && c.bucket >= 0) { entry = &c; break; }
        if (c.lastUse < replacement->lastUse) replacement = &c;
    }
    if (!entry) entry = replacement;
    const bool changed = entry->object != object || entry->bucket != bucket;
    if (changed) { entry->object = object; entry->bucket = bucket; std::snprintf(entry->text, sizeof(entry->text), "%d u", bucket * 5); }
    ImFont* font = ImGui::GetFont(); const float fs = ImGui::GetFontSize();
    if (changed || entry->font != font || entry->fontSize != fs) { entry->size = ImGui::CalcTextSize(entry->text); entry->font = font; entry->fontSize = fs; }
    entry->lastUse = ++clock; return *entry;
}
static bool overlayRectVisible(ImVec2 min, ImVec2 max, ImVec2 viewport, float margin = 0.0f) noexcept {
    return NO7::UI::Extended::IsFinitePoint(min) && NO7::UI::Extended::IsFinitePoint(max) && min.x < max.x && min.y < max.y && max.x + margin > 0.0f && max.y + margin > 0.0f && min.x - margin < viewport.x && min.y - margin < viewport.y;
}
static void drawVisibleOverlayLine(ImDrawList* dl, ImVec2 a, ImVec2 b, ImVec2 viewport, ImU32 color, float thickness) {
    if (!NO7::UI::Extended::IsFinitePoint(a) || !NO7::UI::Extended::IsFinitePoint(b)) return;
    const float margin = thickness * 0.5f + 1.0f;
    if (std::max(a.x, b.x) < -margin || std::max(a.y, b.y) < -margin || std::min(a.x, b.x) > viewport.x + margin || std::min(a.y, b.y) > viewport.y + margin) return;
    NO7::UI::Extended::DrawLine(dl, a, b, color, thickness);
}

static ImVec2 cachedEntityNameSize(const TrackedObject& object) {
    struct Entry {
        uintptr_t object = 0; int group = 0; char text[32]{}; ImFont* font = nullptr; float fontSize = 0; ImVec2 size{}; uint64_t lastUse = 0;
    };
    static thread_local std::array<Entry, 64> entries{};
    static thread_local uint64_t usage = 0;
    Entry* found = nullptr; Entry* oldest = &entries.front();
    for (auto& entry : entries) {
        if (entry.object == object.ptr && entry.lastUse) { found = &entry; break; }
        if (entry.lastUse < oldest->lastUse) oldest = &entry;
    }
    if (!found) found = oldest;
    ImFont* font = ImGui::GetFont();
    const float fontSize = ImGui::GetFontSize();
    if (found->object != object.ptr || found->group != object.groupId || found->font != font || found->fontSize != fontSize || std::memcmp(found->text, object.name, sizeof(found->text)) != 0) {
        found->object = object.ptr; found->group = object.groupId;
        std::memcpy(found->text, object.name, sizeof(found->text));
        found->font = font; found->fontSize = fontSize;
        found->size = ImGui::CalcTextSize(object.name);
    }
    found->lastUse = ++usage;
    return found->size;
}

static void drawMenu() {
    static const std::array<char, 4> windowTitle = [] {
        std::array<char, 4> buffer{};
        const std::string& title = NO7_UI_STR("no7");
        std::copy_n(title.c_str(), buffer.size(), buffer.data());
        return buffer;
    }();
    static int selected = 1;
    static float openProgress = 0.0f;
    static float selectionGlow = 1.0f;
    FrameworkConfig draft = g_cfg;
    FrameworkConfig& cfg = draft;
    if (!cfg.menuOpen) {
        openProgress = 0.0f;
        commitUiConfig(draft);
        return;
    }
    const ImGuiIO& io = ImGui::GetIO();
    const ImVec2 display = io.DisplaySize;
    if (!std::isfinite(display.x) || !std::isfinite(display.y) || display.x < 320.0f || display.y < 240.0f) {
        commitUiConfig(draft);
        return;
    }
    const float dt = std::isfinite(io.DeltaTime) ? std::clamp(io.DeltaTime, 0.0f, 0.1f) : 0.0f;
    const float blend = -std::expm1(-dt * 14.0f);
    openProgress += (1.0f - openProgress) * blend;
    selectionGlow += (1.0f - selectionGlow) * blend;
    const float scale = std::clamp(std::min(display.x / 1920.0f, display.y / 1080.0f), 1.0f, 2.5f);
    const float margin = 12.0f * scale;
    const ImVec2 panelSize{ std::min(940.0f * scale, display.x - margin * 2.0f), std::min(690.0f * scale, display.y - margin * 2.0f) };
    const ImVec2 panelPos{ (display.x - panelSize.x) * 0.5f, (display.y - panelSize.y) * 0.5f + 10.0f * scale * (1.0f - openProgress) };
    const ImVec4 accent{0.08f, 0.85f, 0.63f, 1.0f};
    bool saveRequested = false;
    
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, ImGui::GetStyle().Alpha * openProgress);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(18 * scale, 16 * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(10 * scale, 7 * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10 * scale, 10 * scale));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 14 * scale);
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 10 * scale);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 6 * scale);
    ImGui::PushStyleVar(ImGuiStyleVar_GrabRounding, 6 * scale);
    
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(.045f, .055f, .075f, 1));
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(.060f, .072f, .095f, 1));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(.15f, .19f, .24f, 1));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(.91f, .94f, .97f, 1));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled, ImVec4(.51f, .57f, .65f, 1));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(.10f, .13f, .17f, 1));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(.14f, .19f, .24f, 1));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(.16f, .24f, .28f, 1));
    ImGui::PushStyleColor(ImGuiCol_CheckMark, accent);
    ImGui::PushStyleColor(ImGuiCol_SliderGrab, accent);
    ImGui::PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(.20f, .98f, .75f, 1));
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(.10f, .16f, .20f, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(.13f, .25f, .28f, 1));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(.12f, .32f, .31f, 1));
    ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(.08f, .27f, .24f, .80f));
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(.10f, .32f, .28f, .85f));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImVec4(.10f, .38f, .31f, 1));

    ImGui::SetNextWindowPos(panelPos, ImGuiCond_Always);
    ImGui::SetNextWindowSize(panelSize, ImGuiCond_Always);
    const bool visible = ImGui::Begin(windowTitle.data(), nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    
    if (visible) {
        ImGui::TextColored(accent, NO7_UI_STR("no7").c_str()); ImGui::SameLine();
        ImGui::TextDisabled(NO7_UI_STR(" / TELEMETRY").c_str());
        ImGui::SameLine(std::max(ImGui::GetCursorPosX(), ImGui::GetWindowWidth() - 112.0f * scale));
        if (ImGui::Button(NO7_UI_STR("Fechar").c_str(), {88 * scale, 0})) { cfg.menuOpen = false; saveRequested = true; }
        ImGui::Separator(); ImGui::Spacing();
        
        const float sidebarWidth = std::min(155 * scale, ImGui::GetContentRegionAvail().x * .27f);
        ImGui::BeginChild(NO7_UI_STR("Sidebar").c_str(), {sidebarWidth, 0}, true);
        const auto navigationItem = [&](const char* label, int id) {
            if (ImGui::Selectable(label, selected == id, 0, {0, 38 * scale}) && selected != id) { selected = id; selectionGlow = 0; }
            if (selected == id) {
                const ImVec2 a = ImGui::GetItemRectMin(), b = ImGui::GetItemRectMax();
                ImDrawList* dl = ImGui::GetWindowDrawList();
                const float alpha = ImGui::GetStyle().Alpha * selectionGlow;
                const ImU32 glow = ImGui::ColorConvertFloat4ToU32({accent.x, accent.y, accent.z, .10f * alpha});
                const ImU32 edge = ImGui::ColorConvertFloat4ToU32({accent.x, accent.y, accent.z, .90f * alpha});
                dl->AddRect(a, b, glow, 5 * scale, 0, 3 * scale);
                dl->AddLine({a.x + scale, a.y + 6 * scale}, {a.x + scale, b.y - 6 * scale}, edge, 2 * scale);
            }
        };
        navigationItem(NO7_UI_STR("HOME").c_str(), 0); navigationItem(NO7_UI_STR("VISUALS").c_str(), 1); navigationItem(NO7_UI_STR("ABOUT").c_str(), 3);
        ImGui::EndChild(); ImGui::SameLine();
        ImGui::BeginChild(NO7_UI_STR("MainPanel").c_str(), {0, 0}, true);
        ImGui::PushItemWidth(-1);
        const auto section = [&](const char* title) { ImGui::Spacing(); ImGui::TextColored(accent, "%s", title); ImGui::Separator(); ImGui::Spacing(); };
        const auto slider = [&](const char* label, float* value, float low, float high, const char* format) {
            ImGui::PushID(label); ImGui::TextUnformatted(label); ImGui::SliderFloat(NO7_UI_STR("##v").c_str(), value, low, high, format); ImGui::PopID();
        };

        if (selected == 0) {
            section(NO7_UI_STR("PAINEL DE TELEMETRIA").c_str());
            ImGui::TextWrapped(NO7_UI_STR("Configure a sobreposicao visual e acompanhe as metricas de renderizacao.").c_str());
            ImGui::Spacing(); ImGui::TextDisabled(NO7_UI_STR("INSERT: abrir / fechar").c_str()); ImGui::Spacing();
            if (ImGui::Button(NO7_UI_STR("Desativar framework").c_str(), {-1, 0})) RequestFrameworkStop();
            ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
            ImGui::TextDisabled(NO7_UI_STR("Offsets carregados de:").c_str());
            ImGui::TextWrapped("C:\\Windows\\Temp\\no7_offsets.ini");
        } else if (selected == 1) {
            section(NO7_UI_STR("SOBREPOSICAO").c_str());
            ImGui::Checkbox(NO7_UI_STR("Ativar overlay").c_str(), &cfg.visualEnabled);
            ImGui::Checkbox(NO7_UI_STR("Caixas").c_str(), &cfg.visualBox);
            ImGui::Checkbox(NO7_UI_STR("Estrutura de nos").c_str(), &cfg.visualNodes);
            ImGui::Checkbox(NO7_UI_STR("Linhas de conexao").c_str(), &cfg.visualLines);
            ImGui::Checkbox(NO7_UI_STR("Distancias").c_str(), &cfg.visualDistance);
            ImGui::Checkbox(NO7_UI_STR("Objeto local").c_str(), &cfg.visualSelf);
            ImGui::Separator();
            ImGui::Checkbox(NO7_UI_STR("Barra de Vida").c_str(), &cfg.visualHealth);
            ImGui::Checkbox(NO7_UI_STR("Nome do Alvo").c_str(), &cfg.visualName);
            slider(NO7_UI_STR("Limite de distancia (0 = sem limite)").c_str(), &cfg.maxRenderDist, 0, 1000, NO7_UI_STR("%.0f u").c_str());
            slider(NO7_UI_STR("Espessura das caixas e linhas").c_str(), &cfg.boxThickness, .5f, 5, NO7_UI_STR("%.1f").c_str());
            slider(NO7_UI_STR("Espessura dos nos").c_str(), &cfg.nodeThickness, .5f, 5, NO7_UI_STR("%.1f").c_str());
            ImGui::ColorEdit4(NO7_UI_STR("Cor dos objetos").c_str(), cfg.colTarget);
            ImGui::ColorEdit4(NO7_UI_STR("Cor local").c_str(), cfg.colFriendly);
            
            section(NO7_UI_STR("CAMERA").c_str());
            ImGui::Checkbox(NO7_UI_STR("Ativar tracking").c_str(), &cfg.trackingEnabled);
            ImGui::Checkbox(NO7_UI_STR("Exibir raio").c_str(), &cfg.showTrackingRange);
            ImGui::Checkbox(NO7_UI_STR("Check Visibilidade (Raycast)").c_str(), &cfg.checkVisibility);
            slider(NO7_UI_STR("Raio de tracking").c_str(), &cfg.trackingRange, 10, 400, NO7_UI_STR("%.0f px").c_str());
            slider(NO7_UI_STR("Suavizacao").c_str(), &cfg.trackingSmooth, 5, 20, NO7_UI_STR("%.1f").c_str());
            ImGui::Checkbox(NO7_UI_STR("Estabilizacao").c_str(), &cfg.stabilization);
        } else {
            section(NO7_UI_STR("RENDERIZACAO").c_str());
            const auto& stats = g_optimizer.GetStats();
            ImGui::Text(NO7_UI_STR("FPS: %.1f").c_str(), stats.FPS);
            ImGui::Text(NO7_UI_STR("Tempo por frame: %.2f ms").c_str(), stats.SmoothedFrameTimeMs);
            ImGui::Text(NO7_UI_STR("Escala da interface: %.0f%%").c_str(), scale * 100);
            ImGui::Spacing();
            ImGui::TextWrapped(NO7_UI_STR("Distancias exibidas em intervalos de 5 unidades.").c_str());
            ImGui::TextDisabled(NO7_UI_STR("Edite no7_offsets.ini para atualizar offsets sem recompilar.").c_str());
        }
        ImGui::PopItemWidth(); ImGui::EndChild();
    }
    ImGui::End();
    ImGui::PopStyleColor(17); ImGui::PopStyleVar(8);
    commitUiConfig(draft);
    if (saveRequested) SaveConfig();
}

static void renderOverlay(const FrameSnapshot& s) {
    const auto configuration = acquireFrameConfig();
    const FrameworkConfig& cfg = *configuration;
    const ImVec2 display = ImGui::GetIO().DisplaySize;
    if (!std::isfinite(display.x) || !std::isfinite(display.y) || display.x <= 0 || display.y <= 0 || display.x > 100000 || display.y > 100000) return;
    const int sw = static_cast<int>(display.x), sh = static_cast<int>(display.y);
    if (sw <= 0 || sh <= 0) return;

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const float cx = sw * .5f, cy = sh * .5f;
    if (cfg.trackingEnabled && cfg.showTrackingRange) dl->AddCircle({cx, cy}, cfg.trackingRange, IM_COL32(255,255,255,80), 64, 1);

    if (!cfg.visualEnabled || !s.matrixOk || !snapshotFresh(s)) return;
    const bool drawObjects = cfg.visualBox || cfg.visualNodes || cfg.visualDistance || cfg.visualLines || cfg.visualHealth || cfg.visualName;
    if (!drawObjects && !cfg.visualSelf) return;

    const ImU32 target = ImGui::ColorConvertFloat4ToU32({cfg.colTarget[0], cfg.colTarget[1], cfg.colTarget[2], cfg.colTarget[3]});
    const ImU32 nodeColor = IM_COL32(255,255,255,180);
    const float boxMargin = cfg.boxThickness * .5f + 1;
    const ImVec2 lineOrigin{cx, static_cast<float>(sh)};

    dl->PushClipRect({0, 0}, display, true);
    if (drawObjects) {
        struct ProjectedBox {
            ImVec2 min{}, max{}, lineEnd{};
            float height = 0;
            bool eligible = false, projected = false, visible = false;
        };
        for (size_t i = 0; i < s.objects.size(); i += 4) {
            Vec3 tops[4]{}, bottoms[4]{};
            ScreenPoint tp[4], bp[4];
            std::array<ProjectedBox, 4> boxes{};
            const size_t count = std::min<size_t>(4, s.objects.size() - i);
            bool anyEligible = false;
            for (size_t j = 0; j < count; ++j) {
                const auto& e = s.objects[i+j];
                boxes[j].eligible = e.valid && e.ptr != s.localPtr && !(s.localPosOk && cfg.maxRenderDist > 0 && e.distance > cfg.maxRenderDist);
                if (!boxes[j].eligible) continue;
                anyEligible = true;
                tops[j] = e.topPos; bottoms[j] = e.pos; bottoms[j].z -= 40;
            }
            if (!anyEligible) continue;
            WorldToScreen4(tops, s.viewMatrix, sw, sh, tp);
            WorldToScreen4(bottoms, s.viewMatrix, sw, sh, bp);
            for (size_t j = 0; j < count; ++j) {
                auto& box = boxes[j];
                if (!box.eligible || !tp[j].valid || !bp[j].valid) continue;
                box.height = bp[j].y - tp[j].y;
                if (!std::isfinite(box.height) || box.height < 4 || box.height > 2000) continue;
                const float halfWidth = box.height * .225f;
                box.min = {bp[j].x - halfWidth, tp[j].y};
                box.max = {bp[j].x + halfWidth, bp[j].y};
                box.lineEnd = {tp[j].x, tp[j].y};
                box.visible = overlayRectVisible(box.min, box.max, display, boxMargin);
                box.projected = true;
            }
            for (size_t j = 0; j < count; ++j) {
                const auto& box = boxes[j];
                if (!box.projected) continue;
                const auto& e = s.objects[i+j];
                
                if (cfg.visualBox && box.visible) NO7::UI::Extended::DrawOutlinedRect(dl, {box.min, box.max}, target, cfg.boxThickness);
                if (cfg.visualHealth && box.visible) {
                    const float fraction = std::clamp(e.health / e.maxHealth, 0.0f, 1.0f);
                    const float barHeight = box.height * fraction;
                    const ImU32 color = IM_COL32(static_cast<int>(255*(1-fraction)), static_cast<int>(255*fraction), 0, 220);
                    dl->AddRectFilled({box.min.x-5, box.max.y-barHeight}, {box.min.x-2, box.max.y}, color);
                    dl->AddRect({box.min.x-5, box.min.y}, {box.min.x-2, box.max.y}, IM_COL32(0,0,0,180));
                }
                if (cfg.visualName && box.visible) {
                    const ImVec2 size = cachedEntityNameSize(e);
                    const float halfWidth = box.height * .225f;
                    dl->AddText({box.min.x + (halfWidth*2-size.x)*.5f, box.min.y-size.y-2}, target, e.name);
                }
                if (cfg.visualLines) drawVisibleOverlayLine(dl, lineOrigin, box.lineEnd, display, target, cfg.boxThickness);
                if (cfg.visualDistance && s.localPosOk && bp[j].y+2 < display.y) {
                    const auto& label = cachedDistanceLabel(e.ptr, e.distance);
                    const ImVec2 min{bp[j].x-label.size.x*.5f, bp[j].y+2}, max{min.x+label.size.x, min.y+label.size.y};
                    if (overlayRectVisible(min, max, display)) dl->AddText(min, target, label.text);
                }
                if (cfg.visualNodes && e.hasNodes) {
                    Vec3 nodes[4]{e.topPos, e.nodeMid, e.nodeBot, {}}; ScreenPoint np[4];
                    WorldToScreen4(nodes, s.viewMatrix, sw, sh, np);
                    if (np[0].valid && np[1].valid) drawVisibleOverlayLine(dl, {np[0].x,np[0].y}, {np[1].x,np[1].y}, display, nodeColor, cfg.nodeThickness);
                    if (np[1].valid && np[2].valid) drawVisibleOverlayLine(dl, {np[1].x,np[1].y}, {np[2].x,np[2].y}, display, nodeColor, cfg.nodeThickness);
                }
            }
        }
    }
    if (cfg.visualSelf && s.localPtr && s.localPosOk) {
        Vec3 p = s.localPos; p.z += 60;
        float x = 0, y = 0;
        if (worldToScreen(p, s.viewMatrix, sw, sh, x, y)) {
            const ImVec2 min{x-18,y}, max{x+18,y+80};
            if (overlayRectVisible(min, max, display, boxMargin)) {
                const auto* c = cfg.colFriendly;
                NO7::UI::Extended::DrawOutlinedRect(dl, {min,max}, ImGui::ColorConvertFloat4ToU32({c[0],c[1],c[2],c[3]}), cfg.boxThickness);
            }
        }
    }
    dl->PopClipRect();
}

static bool createRTV() {
    if (!g_swap || !g_dev) return false;
    ID3D11Texture2D* back = nullptr;
    if (FAILED(g_swap->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&back)))) return false;
    ID3D11RenderTargetView* next = nullptr;
    const HRESULT hr = g_dev->CreateRenderTargetView(back, nullptr, &next);
    back->Release();
    if (FAILED(hr)) return false;
    releaseCOM(g_rtv); g_rtv = next;
    return true;
}

static bool initImGui(HWND hwnd) {
    if (g_imguiReady) return true;
    if (!g_dev || !g_ctx || !IsWindow(hwnd)) return false;
    IMGUI_CHECKVERSION();
    g_imguiContext = ImGui::CreateContext();
    if (!g_imguiContext) return false;
    ImGui::SetCurrentContext(g_imguiContext);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.FontDefault = io.Fonts->AddFontDefault();
    ImGui::StyleColorsDark();
    auto& style = ImGui::GetStyle();
    style.WindowRounding = 12; style.ChildRounding = 8; style.FrameRounding = 6;
    style.Colors[ImGuiCol_CheckMark] = {0, .88f, .59f, 1};
    style.Colors[ImGuiCol_WindowBg] = {.015f, .020f, .025f, 1};
    const bool win32 = ImGui_ImplWin32_Init(hwnd);
    const bool dx11 = win32 && ImGui_ImplDX11_Init(g_dev, g_ctx);
    if (!dx11 || !createRTV()) {
        if (dx11) ImGui_ImplDX11_Shutdown();
        if (win32) ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext(g_imguiContext); g_imguiContext = nullptr;
        return false;
    }
    g_imguiReady = true;
    return true;
}

LRESULT CALLBACK hkWndProc(HWND, UINT, WPARAM, LPARAM);
static void shutdownGraphics() {
    if (g_graphicsDone.load()) return;
    if (g_swap && g_originalVtbl && g_hookedVtbl) InterlockedCompareExchangePointer(reinterpret_cast<PVOID volatile*>(g_swap), g_originalVtbl, g_hookedVtbl);
    if (IsWindow(g_hwnd) && g_origWndProc && reinterpret_cast<WNDPROC>(GetWindowLongPtrW(g_hwnd, GWLP_WNDPROC)) == hkWndProc) SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(g_origWndProc));
    if (g_imguiReady) { ImGui::SetCurrentContext(g_imguiContext); ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext(g_imguiContext); }
    g_imguiReady = false; g_imguiContext = nullptr;
    releaseCOM(g_rtv); releaseCOM(g_ctx); releaseCOM(g_dev); releaseCOM(g_swap);
    g_graphicsDone = true;
}
struct ContextScope {
    ImGuiContext* previous = ImGui::GetCurrentContext();
    ImGuiContext* frameworkAtEntry = g_imguiContext;
    ContextScope() = default;
    ~ContextScope() {
        if (previous == frameworkAtEntry && frameworkAtEntry != g_imguiContext) previous = nullptr;
        ImGui::SetCurrentContext(previous);
    }
};
LRESULT CALLBACK hkWndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    std::lock_guard<std::recursive_mutex> lock(g_uiMtx);
    ContextScope context;
    if (g_imguiReady && g_running) {
        ImGui::SetCurrentContext(g_imguiContext);
        if (msg == WM_KEYDOWN && wp == VK_INSERT) {
            if (!(lp & (static_cast<LPARAM>(1) << 30))) { g_cfg.menuOpen = !g_cfg.menuOpen; if (!g_cfg.menuOpen) SaveConfig(); }
            return 0;
        }
        if (g_cfg.menuOpen) {
            const LRESULT handled = ImGui_ImplWin32_WndProcHandler(hwnd, msg, wp, lp);
            if (handled) return handled;
        }
    }
    return g_origWndProc ? CallWindowProcW(g_origWndProc,hwnd,msg,wp,lp) : DefWindowProcW(hwnd,msg,wp,lp);
}
struct RenderTargetsScope {
    ID3D11DeviceContext* context;
    ID3D11RenderTargetView* targets[D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT]{};
    ID3D11DepthStencilView* depth = nullptr;
    UINT count = 0;
    explicit RenderTargetsScope(ID3D11DeviceContext* c) : context(c) {
        context->OMGetRenderTargets(D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT, targets, &depth);
        for (UINT i = 0; i < D3D11_SIMULTANEOUS_RENDER_TARGET_COUNT; ++i) if (targets[i]) count = i + 1;
    }
    ~RenderTargetsScope() {
        context->OMSetRenderTargets(count, targets, depth);
        for (auto*& t : targets) releaseCOM(t);
        releaseCOM(depth);
    }
};
HRESULT __stdcall hkPresent(IDXGISwapChain* sc, UINT sync, UINT flags) {
    {
        std::lock_guard<std::recursive_mutex> lock(g_uiMtx);
        ContextScope context;
        if (!g_running) shutdownGraphics();
        else if (!(flags & DXGI_PRESENT_TEST)) {
            try {
                if (!g_imguiReady) {
                    releaseCOM(g_ctx); releaseCOM(g_dev);
                    if (SUCCEEDED(sc->GetDevice(__uuidof(ID3D11Device), reinterpret_cast<void**>(&g_dev)))) {
                        g_dev->GetImmediateContext(&g_ctx);
                        DXGI_SWAP_CHAIN_DESC desc{};
                        if (SUCCEEDED(sc->GetDesc(&desc)) && initImGui(desc.OutputWindow)) {
                            g_hwnd = desc.OutputWindow;
                            SetLastError(ERROR_SUCCESS);
                            const LONG_PTR prev = SetWindowLongPtrW(g_hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(hkWndProc));
                            if (prev) g_origWndProc = reinterpret_cast<WNDPROC>(prev);
                            else RequestFrameworkStop();
                        }
                    }
                }
                if (g_imguiReady && g_running) {
                    ImGui::SetCurrentContext(g_imguiContext);
                    if (!g_rtv) createRTV();
                    if (g_rtv) {
                        static thread_local FrameSnapshot snap;
                        copySnapshotForRender(snap);
                        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
                        g_optimizer.BeginFrame(); drawMenu();
                        if (g_running) {
                            renderOverlay(snap);
                            if (acquireFrameConfig()->trackingEnabled) processTracking(snap);
                            if (acquireFrameConfig()->stabilization) processStabilization(snap);
                        }
                        ImGui::Render();
                        RenderTargetsScope restore(g_ctx);
                        g_ctx->OMSetRenderTargets(1, &g_rtv, nullptr);
                        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
                    }
                }
            } catch (...) { RequestFrameworkStop(); }
            if (!g_running) shutdownGraphics();
        }
    }
    return g_origPresent(sc, sync, flags);
}
HRESULT __stdcall hkResizeBuffers(IDXGISwapChain* sc, UINT n, UINT w, UINT h, DXGI_FORMAT format, UINT flags) {
    std::lock_guard<std::recursive_mutex> lock(g_uiMtx);
    ContextScope context;
    if (!g_running) shutdownGraphics();
    releaseCOM(g_rtv);
    const HRESULT result = g_origResize(sc,n,w,h,format,flags);
    if (SUCCEEDED(result) && g_imguiReady) createRTV();
    return result;
}

template<typename T> static bool sameInterfacePointer(IDXGISwapChain* sc) {
    T* next = nullptr;
    if (FAILED(sc->QueryInterface(__uuidof(T), reinterpret_cast<void**>(&next)))) return false;
    const bool same = static_cast<void*>(next) == static_cast<void*>(sc);
    next->Release(); return same;
}
static bool hookSwapChain(IDXGISwapChain* sc) {
    if (!sc || g_hookedVtbl) return false;
    size_t count = 18;
    if (sameInterfacePointer<IDXGISwapChain4>(sc)) count = 41;
    else if (sameInterfacePointer<IDXGISwapChain3>(sc)) count = 40;
    else if (sameInterfacePointer<IDXGISwapChain2>(sc)) count = 36;
    else if (sameInterfacePointer<IDXGISwapChain1>(sc)) count = 29;
    auto original = *reinterpret_cast<void***>(sc);
    auto table = static_cast<void**>(VirtualAlloc(nullptr,count*sizeof(void*), MEM_COMMIT | MEM_RESERVE,PAGE_READWRITE));
    if (!table) return false;
    std::memcpy(table, original, count*sizeof(void*));
    table[8] = reinterpret_cast<void*>(hkPresent);
    table[13] = reinterpret_cast<void*>(hkResizeBuffers);
    g_origPresent = reinterpret_cast<PresentFn>(original[8]);
    g_origResize = reinterpret_cast<ResizeFn>(original[13]);
    sc->AddRef();
    g_originalVtbl = original; g_hookedVtbl = table; g_swap = sc;
    g_graphicsDone = false;
    const auto prev = InterlockedCompareExchangePointer(reinterpret_cast<PVOID volatile*>(sc), table, original);
    if (prev != original) {
        g_graphicsDone = true; g_swap = nullptr; g_originalVtbl = nullptr; g_hookedVtbl = nullptr;
        sc->Release(); VirtualFree(table,0,MEM_RELEASE); return false;
    }
    return true;
}

static DWORD WINAPI initThread(LPVOID) noexcept {
    bool installed = false; bool workerStarted = false;
    try {
        HMODULE pinned = nullptr;
        if (!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_PIN, reinterpret_cast<LPCWSTR>(g_module), &pinned)) {
            g_running = false; g_workerDone = true; g_state = Failed; return 1;
        }
        LoadConfig();
        const std::string procName = TargetProcess::OBF_PROC_NAME.decrypt();
        const std::wstring wProcName(procName.begin(), procName.end());
        const DWORD currentPid = GetCurrentProcessId();
        HANDLE processes = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (processes != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32W entry{}; entry.dwSize = sizeof(entry);
            if (Process32FirstW(processes, &entry)) {
                do {
                    if (entry.th32ProcessID == currentPid && !_wcsicmp(entry.szExeFile, wProcName.c_str())) { g_targetPid = entry.th32ProcessID; break; }
                } while (Process32NextW(processes, &entry));
            }
            CloseHandle(processes);
        }
        if (!g_targetPid) { g_running = false; g_workerDone = true; g_state = Failed; return 1; }

        for (int i = 0; i < 600 && g_running; ++i) {
            g_exeBase = reinterpret_cast<uintptr_t>(GetModuleHandleW(wProcName.c_str()));
            g_coreBase = reinterpret_cast<uintptr_t>(GetModuleHandleW(TargetProcess::MOD_CORE));
            if (g_exeBase && g_coreBase) {
                g_targetProcess = GetCurrentProcess();
                resolveRaycastAddresses();
                auto sc = rpm<IDXGISwapChain*>(g_exeBase + TargetProcess::SWAP_CHAIN_PTR);
                if (sc) {
                    std::lock_guard<std::recursive_mutex> lock(g_uiMtx);
                    if (!g_running) break;
                    installed = hookSwapChain(sc);
                    if (installed) {
                        g_workerDone = false; g_dataThread = std::thread(dataThreadEntry); workerStarted = true;
                        LONG expected = Initializing; g_state.compare_exchange_strong(expected, Running);
                    }
                    break;
                }
            }
            Sleep(100);
        }
    } catch (...) { RequestFrameworkStop(); g_state = Failed; }
    if (!installed) { if (g_running.exchange(false)) g_state = Failed; }
    if (!workerStarted) g_workerDone = true;
    return installed && workerStarted ? 0 : 1;
}

BOOL WINAPI DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_module = module; DisableThreadLibraryCalls(module);
        g_running = true; g_workerDone = true; g_state = Initializing;
        g_initThreadHandle = CreateThread(nullptr, 0, initThread, nullptr, 0, nullptr);
        if (!g_initThreadHandle) { g_running = false; g_state = Failed; return FALSE; }
    } else if (reason == DLL_PROCESS_DETACH) {
        g_running = false;
        if (g_initThreadHandle) { CloseHandle(g_initThreadHandle); g_initThreadHandle = nullptr; }
        if (g_dataThread.joinable()) { try { g_dataThread.detach(); } catch (...) { return FALSE; } }
    }
    return TRUE;
}
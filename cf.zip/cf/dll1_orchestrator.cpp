// dll1_orchestrator.cpp (Sem checagem de módulo + Delay de 15s + Logs)
#include <windows.h>
#include <winternl.h>
#include <tlhelp32.h>
#include <vector>
#include <thread>
#include <chrono>
#include <cstdio>
#include <cstdarg>

struct MY_PEB_LDR_DATA {
    ULONG Length;
    BOOLEAN Initialized;
    PVOID SsHandle;
    LIST_ENTRY InLoadOrderModuleList;
    LIST_ENTRY InMemoryOrderModuleList;
    LIST_ENTRY InInitializationOrderModuleList;
};

struct MY_LDR_DATA_TABLE_ENTRY {
    LIST_ENTRY InLoadOrderLinks;
    LIST_ENTRY InMemoryOrderLinks;
    LIST_ENTRY InInitializationOrderLinks;
    PVOID DllBase;
    PVOID EntryPoint;
    ULONG SizeOfImage;
    UNICODE_STRING FullDllName;
    UNICODE_STRING BaseDllName;
};

static inline void RemoveLinkEntry(PLIST_ENTRY Entry) {
    Entry->Blink->Flink = Entry->Flink;
    Entry->Flink->Blink = Entry->Blink;
}

static void unlinkSelfFromPEB(HMODULE self) {
    auto* peb = (PEB*)__readgsqword(0x60);
    auto* ldr = (MY_PEB_LDR_DATA*)peb->Ldr;
    PLIST_ENTRY head = &ldr->InLoadOrderModuleList;
    for (PLIST_ENTRY e = head->Flink; e != head; e = e->Flink) {
        auto* ent = CONTAINING_RECORD(e, MY_LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
        if (ent->DllBase == self) {
            RemoveLinkEntry(&ent->InLoadOrderLinks);
            RemoveLinkEntry(&ent->InMemoryOrderLinks);
            RemoveLinkEntry(&ent->InInitializationOrderLinks);
            return;
        }
    }
}

static void Log(const char* fmt, ...) {
    FILE* f = fopen("C:\\cf\\orchestrator_log.txt", "a");
    if (!f) return;
    va_list args;
    va_start(args, fmt);
    vfprintf(f, fmt, args);
    va_end(args);
    fprintf(f, "\n");
    fclose(f);
}

static DWORD findProcess(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W pe{ sizeof(pe) };
    DWORD pid = 0;
    if (Process32FirstW(snap, &pe)) {
        do {
            if (!_wcsicmp(pe.szExeFile, name)) { pid = pe.th32ProcessID; break; }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return pid;
}

static std::vector<BYTE> readFileBytes(const wchar_t* path) {
    std::vector<BYTE> out;
    HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (f == INVALID_HANDLE_VALUE) return out;
    DWORD size = GetFileSize(f, nullptr);
    out.resize(size);
    DWORD got = 0;
    ReadFile(f, out.data(), size, &got, nullptr);
    CloseHandle(f);
    out.resize(got);
    return out;
}

static bool MapDll(HANDLE hProc, BYTE* dllData, size_t dllSize, uintptr_t& outBase, uintptr_t& outEntry) {
    auto* dos = (IMAGE_DOS_HEADER*)dllData;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    auto* nt = (IMAGE_NT_HEADERS*)(dllData + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return false;
    auto* opt = &nt->OptionalHeader;
    if (opt->Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return false;

    BYTE* local = (BYTE*)VirtualAlloc(nullptr, opt->SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!local) return false;
    memcpy(local, dllData, opt->SizeOfHeaders);

    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; ++i) {
        if (sec[i].SizeOfRawData)
            memcpy(local + sec[i].VirtualAddress, dllData + sec[i].PointerToRawData, sec[i].SizeOfRawData);
    }

    BYTE* remote = (BYTE*)VirtualAllocEx(hProc, nullptr, opt->SizeOfImage, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remote) {
        Log("[ERRO] VirtualAllocEx falhou: %lu", GetLastError());
        VirtualFree(local, 0, MEM_RELEASE); return false;
    }

    uintptr_t delta = (uintptr_t)remote - (uintptr_t)opt->ImageBase;
    if (delta) {
        auto& rd = opt->DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (rd.Size) {
            auto* blk = (IMAGE_BASE_RELOCATION*)(local + rd.VirtualAddress);
            BYTE* end = (BYTE*)blk + rd.Size;
            while ((BYTE*)blk < end && blk->SizeOfBlock) {
                WORD* entries = (WORD*)((BYTE*)blk + sizeof(IMAGE_BASE_RELOCATION));
                int n = (blk->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / 2;
                for (int i = 0; i < n; ++i) {
                    int type = entries[i] >> 12;
                    int off = entries[i] & 0xFFF;
                    BYTE* p = local + blk->VirtualAddress + off;
                    if (type == IMAGE_REL_BASED_DIR64) *(uintptr_t*)p += delta;
                    else if (type == IMAGE_REL_BASED_HIGHLOW) *(uint32_t*)p += (uint32_t)delta;
                }
                blk = (IMAGE_BASE_RELOCATION*)((BYTE*)blk + blk->SizeOfBlock);
            }
        }
    }

    auto& idir = opt->DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (idir.Size) {
        auto* imp = (IMAGE_IMPORT_DESCRIPTOR*)(local + idir.VirtualAddress);
        for (; imp->Name; ++imp) {
            const char* modName = (const char*)(local + imp->Name);
            HMODULE mod = LoadLibraryA(modName);
            if (!mod) { VirtualFree(local,0,MEM_RELEASE); return false; }
            auto* thunk = (IMAGE_THUNK_DATA*)(local + imp->FirstThunk);
            auto* orig = imp->OriginalFirstThunk ? (IMAGE_THUNK_DATA*)(local + imp->OriginalFirstThunk) : thunk;
            for (; orig->u1.AddressOfData; ++thunk, ++orig) {
                uintptr_t addr;
                if (orig->u1.Ordinal & IMAGE_ORDINAL_FLAG64) addr = (uintptr_t)GetProcAddress(mod, (LPCSTR)(orig->u1.Ordinal & 0xFFFF));
                else { auto* ibn = (IMAGE_IMPORT_BY_NAME*)(local + orig->u1.AddressOfData); addr = (uintptr_t)GetProcAddress(mod, (LPCSTR)ibn->Name); }
                thunk->u1.Function = addr;
            }
        }
    }

    SIZE_T written = 0;
    if (!WriteProcessMemory(hProc, remote, local, opt->SizeOfImage, &written) || written != opt->SizeOfImage) {
        Log("[ERRO] WriteProcessMemory falhou: %lu (escrito %llu de %llu)", GetLastError(), (unsigned long long)written, (unsigned long long)opt->SizeOfImage);
        VirtualFree(local, 0, MEM_RELEASE); VirtualFreeEx(hProc, remote, 0, MEM_RELEASE); return false;
    }
    VirtualFree(local, 0, MEM_RELEASE);

    outBase = (uintptr_t)remote;
    outEntry = (uintptr_t)remote + opt->AddressOfEntryPoint;
    return true;
}

static bool HijackThread(HANDLE hProc, DWORD pid, uintptr_t entry, uintptr_t base) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    THREADENTRY32 te{ sizeof(te) };
    DWORD tid = 0;
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID == pid) { tid = te.th32ThreadID; break; }
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    if (!tid) { Log("[ERRO] Nenhuma thread encontrada no processo alvo."); return false; }

    HANDLE th = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_SET_CONTEXT, FALSE, tid);
    if (!th) { Log("[ERRO] OpenThread falhou: %lu", GetLastError()); return false; }

    SuspendThread(th);
    CONTEXT ctx{}; ctx.ContextFlags = CONTEXT_FULL;
    if (!GetThreadContext(th, &ctx)) { Log("[ERRO] GetThreadContext falhou: %lu", GetLastError()); ResumeThread(th); CloseHandle(th); return false; }

    BYTE stub[256]; int p = 0;
    BYTE pushes[] = {0x50,0x51,0x52,0x53,0x55,0x56,0x57, 0x41,0x50,0x41,0x51,0x41,0x52,0x41,0x53, 0x41,0x54,0x41,0x55,0x41,0x56,0x41,0x57,0x9C};
    memcpy(stub+p, pushes, sizeof(pushes)); p += sizeof(pushes);

    stub[p++]=0x48; stub[p++]=0xB9; memcpy(stub+p,&base,8); p+=8;
    stub[p++]=0x48; stub[p++]=0xC7; stub[p++]=0xC2; *(DWORD*)(stub+p)=1; p+=4;
    stub[p++]=0x4D; stub[p++]=0x31; stub[p++]=0xC0;
    stub[p++]=0x48; stub[p++]=0xB8; memcpy(stub+p,&entry,8); p+=8;
    stub[p++]=0xFF; stub[p++]=0xD0;
    stub[p++]=0x9D;
    BYTE pops[] = {0x41,0x5F,0x41,0x5E,0x41,0x5D,0x41,0x5C, 0x41,0x5B,0x41,0x5A,0x41,0x59,0x41,0x58, 0x5F,0x5E,0x5D,0x5B,0x5A,0x59,0x58};
    memcpy(stub+p, pops, sizeof(pops)); p += sizeof(pops);

    uintptr_t origRip = ctx.Rip;
    stub[p++]=0x48; stub[p++]=0xB8; memcpy(stub+p,&origRip,8); p+=8;
    stub[p++]=0xFF; stub[p++]=0xE0;

    BYTE* remoteStub = (BYTE*)VirtualAllocEx(hProc, nullptr, p, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!remoteStub) { Log("[ERRO] VirtualAllocEx (stub) falhou: %lu", GetLastError()); ResumeThread(th); CloseHandle(th); return false; }
    WriteProcessMemory(hProc, remoteStub, stub, p, nullptr);

    ctx.Rip = (DWORD64)remoteStub;
    SetThreadContext(th, &ctx);
    ResumeThread(th);
    CloseHandle(th);
    return true;
}

static DWORD WINAPI Orchestrator(LPVOID) {
    Sleep(1000);
    Log("=== Orquestrador iniciado (Sem checagem de modulo) ===");
    const wchar_t* payloadPath = L"C:\\cf\\TelemetryFramework_Master.dll";
    DWORD lastPid = 0;

    for (;;) {
        DWORD pid = findProcess(L"crossfire.exe");
        if (pid && pid != lastPid) {
            Log("[INFO] Processo crossfire.exe encontrado. PID: %lu", pid);
            lastPid = pid;
            
            Log("[INFO] Aguardando 15 segundos para o jogo carregar os assets...");
            Sleep(15000);

            Log("[INFO] Tentando abrir o processo...");
            HANDLE hProc = OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ | PROCESS_QUERY_INFORMATION | PROCESS_CREATE_THREAD, FALSE, pid);
            if (hProc) {
                Log("[OK] OpenProcess com sucesso. Lendo payload...");
                std::vector<BYTE> dll = readFileBytes(payloadPath);
                if (!dll.empty()) {
                    Log("[OK] Payload lido (%llu bytes). Iniciando Manual Map...", (unsigned long long)dll.size());
                    uintptr_t base = 0, entry = 0;
                    if (MapDll(hProc, dll.data(), dll.size(), base, entry)) {
                        Log("[OK] Manual Map concluido. Base: 0x%llX. Iniciando Hijack...", (unsigned long long)base);
                        if (HijackThread(hProc, pid, entry, base)) {
                            Log("[SUCESSO] Thread hijack concluido. Cheat injetado.");
                        } else {
                            Log("[ERRO] HijackThread falhou.");
                        }
                    } else {
                        Log("[ERRO] MapDll falhou.");
                    }
                } else {
                    Log("[ERRO] Nao foi possivel ler o payload em: %ls", payloadPath);
                }
                CloseHandle(hProc);
            } else {
                Log("[FALHA CRITICA] OpenProcess falhou com erro: %lu", GetLastError());
                if (GetLastError() == 5) {
                    Log(">> ERRO 5 (ACCESS DENIED): O XIGNCODE bloqueou o handle. O driver kernel e obrigatorio.");
                }
            }
        } else if (!pid) {
            lastPid = 0;
        }
        Sleep(1000);
    }
}

BOOL WINAPI DllMain(HMODULE hModule, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(hModule);
        unlinkSelfFromPEB(hModule);
        CreateThread(nullptr, 0, Orchestrator, nullptr, 0, nullptr);
    }
    return TRUE;
}
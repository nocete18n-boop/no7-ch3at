// injector.cpp (corrigido)
#include <windows.h>
#include <tlhelp32.h>
#include <cstdio>

static bool enableDebugPriv() {
    HANDLE tok = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &tok)) return false;
    TOKEN_PRIVILEGES tp{};
    tp.PrivilegeCount = 1;
    LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &tp.Privileges[0].Luid); // <-- ALTERADO AQUI
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    BOOL ok = AdjustTokenPrivileges(tok, FALSE, &tp, sizeof(tp), nullptr, nullptr);
    CloseHandle(tok);
    return ok && GetLastError() == ERROR_SUCCESS;
}

static DWORD findPcaSvcHostPid() {
    SC_HANDLE scm = OpenSCManagerW(nullptr, nullptr, SC_MANAGER_ENUMERATE_SERVICE);
    if (!scm) return 0;
    DWORD needed = 0, count = 0, resume = 0;
    EnumServicesStatusExW(scm, SC_ENUM_PROCESS_INFO, SERVICE_WIN32, SERVICE_STATE_ALL, nullptr, 0, &needed, &count, &resume, nullptr);
    BYTE* buf = (BYTE*)malloc(needed);
    DWORD pid = 0;
    if (EnumServicesStatusExW(scm, SC_ENUM_PROCESS_INFO, SERVICE_WIN32, SERVICE_STATE_ALL, buf, needed, &needed, &count, &resume, nullptr)) {
        auto* svc = (ENUM_SERVICE_STATUS_PROCESSW*)buf;
        for (DWORD i = 0; i < count; ++i) {
            if (!_wcsicmp(svc[i].lpServiceName, L"PcaSvc")) { pid = svc[i].ServiceStatusProcess.dwProcessId; break; }
        }
    }
    free(buf);
    CloseServiceHandle(scm);
    return pid;
}

static bool injectLoadLibrary(DWORD pid, const wchar_t* dllPath) {
    HANDLE h = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, pid);
    if (!h) { wprintf(L"OpenProcess falhou: %lu\n", GetLastError()); return false; }
    SIZE_T bytes = (wcslen(dllPath) + 1) * sizeof(wchar_t);
    void* remote = VirtualAllocEx(h, nullptr, bytes, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) { CloseHandle(h); return false; }
    WriteProcessMemory(h, remote, dllPath, bytes, nullptr);
    HMODULE k32 = GetModuleHandleW(L"kernel32.dll");
    auto loadLib = (LPTHREAD_START_ROUTINE)GetProcAddress(k32, "LoadLibraryW");
    HANDLE th = CreateRemoteThread(h, nullptr, 0, loadLib, remote, 0, nullptr);
    if (!th) { CloseHandle(h); return false; }
    WaitForSingleObject(th, 5000);
    CloseHandle(th); CloseHandle(h);
    return true;
}

int wmain(int argc, wchar_t** argv) {
    if (argc < 2) { wprintf(L"uso: injector.exe <dll1.dll>\n"); return 1; }
    if (!enableDebugPriv()) wprintf(L"aviso: SeDebugPrivilege nao habilitado\n");
    DWORD pid = findPcaSvcHostPid();
    if (!pid) { wprintf(L"PcaSvc nao encontrado\n"); return 1; }
    wprintf(L"PcaSvc svchost PID = %lu\n", pid);
    if (!injectLoadLibrary(pid, argv[1])) { wprintf(L"injecao falhou\n"); return 1; }
    wprintf(L"dll1 injetada\n");
    return 0;
}